require "{{NAME}}/version"

module {{NAME}}
  # Your code goes here...
end
